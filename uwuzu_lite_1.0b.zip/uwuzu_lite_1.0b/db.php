<?php // データベースの接続情報
define( 'DB_HOST', 'localhost');
define( 'DB_USER', 'root');
define( 'DB_PASS', 'root');
define( 'DB_NAME', 'uwuzu_db');

// タイムゾーン設定
date_default_timezone_set('Asia/Tokyo');
?>
<?php ?>
<div class="admin_left">
    <a href="overview_admin" class="admin_leftbtn">概要</a>
    <a href="serveradmin" class="admin_leftbtn">サーバー設定</a>
    <a href="useradmin" class="admin_leftbtn">ユーザー管理</a>
    <a href="codeadmin" class="admin_leftbtn">招待コード発行所</a>
    <a href="role_admin" class="admin_leftbtn">ロール</a>
    <a href="ad_admin" class="admin_leftbtn">広告</a>
    <a href="moderation_admin" class="admin_leftbtn">モデレーション</a>
    <a href="customize_admin" class="admin_leftbtn">カスタマイズ</a>
</div>
<?php ?>
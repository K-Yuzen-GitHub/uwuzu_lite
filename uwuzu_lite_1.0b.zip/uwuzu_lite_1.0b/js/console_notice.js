console.log(
    "%c警告!!!%c\nもし誰かにここに%cコピペ%cしろと言われたりCookieというものをコピーしろなどと言われているのであればその行為は%c今すぐやめて%cください。",
    "color:white; background-color:#FF4848; padding:4px; border-radius:4px; font-weight: bold; font-size: 16pt",
    "",
    "color:#FF4848; font-size: 16pt; font-weight: bold;",
    "",
    "color:#FF4848; font-size: 16pt; font-weight: bold;",
    "",
);
console.log(
    "ここに何かを貼り付けてしまうと%c悪意のあるユーザー%cにより%cあなたのアカウントが乗っ取られる%c可能性が大いにあります。",
    "color:#FF4848; font-weight: bold;",
    "",
    "color:#FF4848; font-weight: bold;",
    "",
);
console.log(
    "自分で意図して行っていないのであれば%c今直ぐにこのツールを閉じて%cログアウトもしくはCookieとセッションの削除をするべきです。",
    "color:#FF4848; font-weight: bold;",
    "",
);
console.log(
    "%cMessage by uwuzu%c\n%cこのメッセージはuwuzu開発者であるだいちまるによって書き込まれたものです。%c",
    "color:white; background-color:#FFC832; padding:4px; border-radius:4px; font-size: 12pt",
    "",
    "color:#000;",
    "",
    "uwuzuサーバー運営者及びuwuzu開発者がCookie情報等を要求することはありません。",
);